
import React, { useCallback } from 'react';
import { PortfolioAnalyzerForm } from './PortfolioAnalyzerForm';
import { ReportViewer } from './ReportViewer';
import { fetchAnalysisReport } from '../services/analysisService';
import { AnalysisParams, AnalysisResponse } from '../types';

interface QuantStatsAnalyzerProps {
  formParams: AnalysisParams;
  setFormParams: React.Dispatch<React.SetStateAction<AnalysisParams>>;
  reportUrl: string | null;
  setReportUrl: React.Dispatch<React.SetStateAction<string | null>>;
  isLoading: boolean;
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
  error: string | null;
  setError: React.Dispatch<React.SetStateAction<string | null>>;
}

export const QuantStatsAnalyzer: React.FC<QuantStatsAnalyzerProps> = ({
  formParams,
  setFormParams,
  reportUrl,
  setReportUrl,
  isLoading,
  setIsLoading,
  error,
  setError,
}) => {
  const handleParamChange = useCallback(
    <K extends keyof AnalysisParams>(key: K, value: AnalysisParams[K]) => {
      setFormParams((prev) => ({ ...prev, [key]: value }));
    },
    [setFormParams]
  );

  const handleSubmit = useCallback(async () => {
    if (!formParams.symbols || !formParams.start_date || !formParams.end_date) {
      setError('Symbol, Start Date, and End Date are required.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setReportUrl(null); // Clear previous report URL

    try {
      const serviceParams = {
        symbols: formParams.symbols,
        start_date: formParams.start_date,
        end_date: formParams.end_date,
        benchmark: formParams.benchmark.trim() === '' ? undefined : formParams.benchmark,
        risk_free_rate: formParams.risk_free_rate.trim() === '' ? undefined : parseFloat(formParams.risk_free_rate),
      };
      
      const response: AnalysisResponse = await fetchAnalysisReport(serviceParams);
      setReportUrl(response.html_url);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred.');
      }
      setReportUrl(null);
    } finally {
      setIsLoading(false);
    }
  }, [formParams, setError, setIsLoading, setReportUrl]);

  return (
    <div className="w-full">
      <div className="flex justify-end mb-3">
        <a
          href="https://rex.tigzig.com/mcp-server-quantstats"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-green-500 hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-400 transition-colors"
        >
          Docs & Source
        </a>
      </div>
      <PortfolioAnalyzerForm
        params={formParams}
        onParamChange={handleParamChange}
        onSubmit={handleSubmit}
        isLoading={isLoading}
      />

      {error && (
        <div className="my-3 bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded-md shadow-sm text-sm" role="alert">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      )}
      
      <div className="mt-3 p-3 bg-light-blue-50 border border-light-blue-200 rounded-md min-h-[60px] flex items-center"> {/* Fixed height URL display area */}
        <p className="text-sm text-gray-700 break-all">
          <span className="font-medium">Report HTML URL:</span>{' '}
          {isLoading && !reportUrl && <span className="italic">Generating...</span>}
          {!isLoading && reportUrl && (
            <a
              href={reportUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-light-blue-600 hover:text-light-blue-800 hover:underline"
            >
              {reportUrl}
            </a>
          )}
          {!isLoading && !reportUrl && !error && <span className="italic">Not generated yet.</span>}
          {!isLoading && !reportUrl && error && <span className="italic text-red-600">Failed to generate.</span>}
        </p>
      </div>

      {isLoading && !reportUrl && (
         <div className="mt-6 text-center p-4">
           <p className="text-lg text-light-blue-600">Generating QuantStats report, this may take a few minutes...</p>
         </div>
      )}

      {/* ReportViewer will now always render its container, showing placeholder or iframe */}
      <ReportViewer reportUrl={reportUrl} />
    </div>
  );
};
