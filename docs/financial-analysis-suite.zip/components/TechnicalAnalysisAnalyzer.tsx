
import React, { useCallback } from 'react';
import { TechnicalAnalysisForm } from './TechnicalAnalysisForm';
import { TechnicalAnalysisReportViewer } from './TechnicalAnalysisReportViewer';
import { fetchTechnicalAnalysisReport } from '../services/technicalAnalysisService';
import { TechnicalAnalysisFormParams, TechnicalAnalysisResponse } from '../types';

interface TechnicalAnalysisAnalyzerProps {
  formParams: TechnicalAnalysisFormParams;
  setFormParams: React.Dispatch<React.SetStateAction<TechnicalAnalysisFormParams>>;
  reportData: TechnicalAnalysisResponse | null;
  setReportData: React.Dispatch<React.SetStateAction<TechnicalAnalysisResponse | null>>;
  isLoading: boolean;
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
  error: string | null;
  setError: React.Dispatch<React.SetStateAction<string | null>>;
}

export const TechnicalAnalysisAnalyzer: React.FC<TechnicalAnalysisAnalyzerProps> = ({
  formParams,
  setFormParams,
  reportData,
  setReportData,
  isLoading,
  setIsLoading,
  error,
  setError,
}) => {

  const handleParamChange = useCallback(
    <K extends keyof TechnicalAnalysisFormParams>(key: K, value: TechnicalAnalysisFormParams[K]) => {
      setFormParams((prev) => ({ ...prev, [key]: value }));
    },
    [setFormParams]
  );

  const handleSubmit = useCallback(async () => {
    if (!formParams.ticker || !formParams.daily_start_date || !formParams.daily_end_date || !formParams.weekly_start_date || !formParams.weekly_end_date) {
      setError('All fields (Ticker, Daily and Weekly date ranges) are required.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setReportData(null); // Clear previous report data

    try {
      const serviceParams = { ...formParams }; // All params are strings from form
      const response: TechnicalAnalysisResponse = await fetchTechnicalAnalysisReport(serviceParams);
      console.log("TA Report Data Received:", response); // For debugging
      setReportData(response);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred while fetching the TA report.');
      }
      setReportData(null);
    } finally {
      setIsLoading(false);
    }
  }, [formParams, setError, setIsLoading, setReportData]);

  const htmlReportUrlForViewer = reportData?.html_url;
  const pdfReportUrlForLink = reportData?.pdf_url;

  return (
    <div className="w-full">
      <div className="flex justify-end mb-3">
        <a
          href="https://rex.tigzig.com/mcp-server-technical-analysis"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-green-500 hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-400 transition-colors"
        >
          Docs & Source
        </a>
      </div>
      <TechnicalAnalysisForm
        params={formParams}
        onParamChange={handleParamChange}
        onSubmit={handleSubmit}
        isLoading={isLoading}
      />

      {error && (
        <div className="my-3 bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded-md shadow-sm text-sm" role="alert">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      )}

      <div className="mt-3 p-3 bg-light-blue-50 border border-light-blue-200 rounded-md min-h-[80px] flex flex-col justify-center space-y-1">
        <div>
          <p className="text-sm text-gray-700 break-all">
            <span className="font-medium">PDF Report URL:</span>{' '}
            {isLoading && !pdfReportUrlForLink && <span className="italic">Generating...</span>}
            {!isLoading && pdfReportUrlForLink && (
              <a
                href={pdfReportUrlForLink}
                target="_blank"
                rel="noopener noreferrer"
                className="text-light-blue-600 hover:text-light-blue-800 hover:underline"
              >
                {pdfReportUrlForLink}
              </a>
            )}
            {!isLoading && !pdfReportUrlForLink && !error && <span className="italic">Not generated yet.</span>}
            {!isLoading && !pdfReportUrlForLink && error && <span className="italic text-red-600">Failed to generate.</span>}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-700 break-all">
            <span className="font-medium">HTML Report URL:</span>{' '}
            {isLoading && !htmlReportUrlForViewer && <span className="italic">Generating...</span>}
            {!isLoading && htmlReportUrlForViewer && (
              <a
                href={htmlReportUrlForViewer} 
                target="_blank"
                rel="noopener noreferrer"
                className="text-light-blue-600 hover:text-light-blue-800 hover:underline"
              >
                {htmlReportUrlForViewer} 
              </a>
            )}
            {!isLoading && !htmlReportUrlForViewer && !error && <span className="italic">Not generated yet.</span>}
            {!isLoading && !htmlReportUrlForViewer && error && <span className="italic text-red-600">Failed to generate.</span>}
          </p>
        </div>
      </div>
      
      {isLoading && !reportData && (
         <div className="mt-6 text-center p-4">
           <p className="text-lg text-light-blue-600">Generating Technical Analysis report, this may take some time...</p>
         </div>
      )}
      
      <TechnicalAnalysisReportViewer htmlUrl={htmlReportUrlForViewer} />
    </div>
  );
};
