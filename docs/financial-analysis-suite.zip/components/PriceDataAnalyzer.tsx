
import React, { useCallback } from 'react';
import { PriceDataForm } from './PriceDataForm';
import { DataTableView } from './DataTableView';
import { fetchHistoricalPrices } from '../services/yfinanceService';
import { exportToCsv, exportToExcel } from '../utils/dataExportUtils';
import { PriceDataFormParams, YFinanceHistoricalPricesData, YFinanceDataType } from '../types';

interface PriceDataAnalyzerProps {
  formParams: PriceDataFormParams;
  setFormParams: React.Dispatch<React.SetStateAction<PriceDataFormParams>>;
  fetchedData: YFinanceHistoricalPricesData | null;
  setFetchedData: React.Dispatch<React.SetStateAction<YFinanceHistoricalPricesData | null>>;
  isLoading: boolean;
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
  error: string | null;
  setError: React.Dispatch<React.SetStateAction<string | null>>;
}

const LoadingSpinner: React.FC = () => (
  <svg className="animate-spin inline-block -ml-1 mr-2 h-4 w-4 text-light-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>
);

export const PriceDataAnalyzer: React.FC<PriceDataAnalyzerProps> = ({
  formParams,
  setFormParams,
  fetchedData,
  setFetchedData,
  isLoading,
  setIsLoading,
  error,
  setError,
}) => {
  const handleParamChange = useCallback(
    <K extends keyof PriceDataFormParams>(key: K, value: PriceDataFormParams[K]) => {
      setFormParams((prev) => ({ ...prev, [key]: value }));
    },
    [setFormParams]
  );

  const handleSubmit = useCallback(async () => {
    if (!formParams.symbol || !formParams.start_date || !formParams.end_date) {
      setError('Symbol, Start Date, and End Date are required.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setFetchedData(null);

    try {
      const response = await fetchHistoricalPrices(formParams.symbol, formParams.start_date, formParams.end_date);
      
      // FIX: Adjusted for YFinanceHistoricalPricesData union type
      if (response && 'error' in response && typeof response.error === 'string') {
        setError(`API Error: ${response.error}`);
        setFetchedData(null);
      } else {
        // response is YFinanceHistoricalDateMap
        // Check if the response (which is now YFinanceHistoricalDateMap) is empty
        const dataKeys = Object.keys(response);
        if (dataKeys.length === 0) {
          setError(`No historical price data found for ${formParams.symbol} in the selected date range.`);
          setFetchedData(null);
        } else {
          setFetchedData(response);
        }
      }
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred while fetching historical price data.');
      }
      setFetchedData(null);
    } finally {
      setIsLoading(false);
    }
  }, [formParams, setError, setIsLoading, setFetchedData]);

  const handleDownloadCsv = () => {
    if (fetchedData && formParams.symbol) {
      exportToCsv(fetchedData, `${formParams.symbol}_historical_prices.csv`, YFinanceDataType.HISTORICAL_PRICES, formParams.symbol);
    }
  };

  const handleDownloadExcel = () => {
    if (fetchedData && formParams.symbol) {
      exportToExcel(fetchedData, `${formParams.symbol}_historical_prices.xlsx`, YFinanceDataType.HISTORICAL_PRICES, formParams.symbol);
    }
  };
  
  // FIX: Adjusted for YFinanceHistoricalPricesData union type
  const dataAvailable = fetchedData && !('error' in fetchedData) && Object.keys(fetchedData).length > 0;

  return (
    <div className="w-full">
      <div className="flex justify-end mb-3">
        <a
          href="https://rex.tigzig.com/mcp-server-yahoo-finance"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-green-500 hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-400 transition-colors"
        >
          Docs & Source
        </a>
      </div>
      <PriceDataForm
        params={formParams}
        onParamChange={handleParamChange}
        onSubmit={handleSubmit}
        isLoading={isLoading}
      />

      {isLoading && (
        <div className="my-4 p-3 text-center text-light-blue-600">
          <LoadingSpinner /> Fetching historical prices for {formParams.symbol}...
        </div>
      )}

      {error && (
        <div className="my-3 bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded-md shadow-sm text-sm" role="alert">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      )}

      {dataAvailable && (
        <div className="my-4 p-3 bg-light-blue-50 border border-light-blue-200 rounded-md">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Historical Prices for {formParams.symbol.toUpperCase()}</h3>
          <div className="space-x-3">
            <button
              onClick={handleDownloadCsv}
              className="px-4 py-2 bg-green-500 text-white text-sm font-medium rounded-md hover:bg-green-600 transition-colors shadow-sm"
            >
              Download CSV
            </button>
            <button
              onClick={handleDownloadExcel}
              className="px-4 py-2 bg-blue-500 text-white text-sm font-medium rounded-md hover:bg-blue-600 transition-colors shadow-sm"
            >
              Download Excel
            </button>
          </div>
        </div>
      )}
      
      <div className="mt-4">
        {dataAvailable ? (
          <DataTableView data={fetchedData} dataType={YFinanceDataType.HISTORICAL_PRICES} symbol={formParams.symbol} />
        ) : (
          !isLoading && !error && (
            <div className="p-4 text-center text-gray-500 italic border border-gray-200 rounded-md bg-gray-50 min-h-[140px] flex items-center justify-center"> {/* Reduced min-height */}
              No data to display. Enter a symbol, date range, and click "Generate".
            </div>
          )
        )}
      </div>
    </div>
  );
};
