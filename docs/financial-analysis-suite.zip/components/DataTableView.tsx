
import React from 'react';
import { 
  YFinanceCombinedApiResponse, 
  YFinanceDataType, 
  YFinanceCompanyProfileData, 
  YFinanceFinancialStatementData, 
  YFinanceFinancialStatementItem,
  YFinanceHistoricalPricesData, // Union type: YFinanceHistoricalDateMap | { error: string }
  HistoricalPriceEntry,
  YFinanceApiResponse // Keep for casting clarity
} from '../types';

interface DataTableViewProps {
  data: YFinanceCombinedApiResponse | null;
  dataType: YFinanceDataType;
  symbol: string; // Symbol is needed to extract correct data, especially for historical prices
}

// FIX: Changed component definition to React.FC to ensure correct component typing
// and resolve JSX element type mismatches.
export const DataTableView: React.FC<DataTableViewProps> = ({ data, dataType, symbol }) => {
  if (!data) {
    return <p className="text-gray-500 italic">No data to display.</p>;
  }

  // FIX: Explicitly type the return as React.ReactElement for clarity and consistency.
  const renderTableContainer = (content: React.ReactNode): React.ReactElement => (
    <div className="overflow-x-auto bg-white border border-gray-200 rounded-lg shadow max-h-[calc(100vh-530px)] sm:max-h-[calc(100vh-510px)] xl:max-h-[340px] overflow-y-auto"> {/* Added max-height and y-scroll */}
      <table className="min-w-full divide-y divide-gray-200 text-sm">
        {content}
      </table>
    </div>
  );

  if (dataType === YFinanceDataType.HISTORICAL_PRICES) {
    // data is YFinanceHistoricalPricesData, which is YFinanceHistoricalDateMap | { error: string }
    const historicalData = data as YFinanceHistoricalPricesData; 
    const upperSymbol = symbol.toUpperCase();

    // FIX: Handle top-level error for YFinanceHistoricalPricesData (union type)
    if ('error' in historicalData && typeof historicalData.error === 'string') {
        return <p className="text-red-500">Error: {historicalData.error}</p>;
    }

    // At this point, historicalData is YFinanceHistoricalDateMap
    const priceDataMap = historicalData;

    // FIX: Object.keys directly on priceDataMap, no need to filter 'error' key as it's not part of YFinanceHistoricalDateMap
    const dates = Object.keys(priceDataMap).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

    if (dates.length === 0) {
      return (
        <div className="p-4 text-center text-gray-500 italic border border-gray-200 rounded-md bg-gray-50 min-h-[140px] flex items-center justify-center">
          No historical price data available for {upperSymbol}.
        </div>
      );
    }
    
    const hasSymbolDataOnAnyDate = dates.some(date => {
        const dayCellData = priceDataMap[date];
        // Check if dayCellData is the data variant (not error) and contains the symbol
        return dayCellData && !('error' in dayCellData && dayCellData.error) && dayCellData[upperSymbol];
    });

    if (!hasSymbolDataOnAnyDate) {
        return (
          <div className="p-4 text-center text-gray-500 italic border border-gray-200 rounded-md bg-gray-50 min-h-[140px] flex items-center justify-center">
            No historical price data available for symbol '{upperSymbol}' in the response for the given dates.
          </div>
        );
    }

    const headers = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'Dividends', 'Stock Splits'];
    
    return renderTableContainer(
      <>
        <thead className="bg-gray-50">
          <tr>
            {headers.map(header => (
              <th key={header} scope="col" className={`px-4 py-2.5 text-xs font-semibold text-gray-600 uppercase tracking-wider ${header === 'Date' ? 'text-left sticky left-0 bg-gray-50 z-10' : 'text-right'}`}>
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-100">
          {dates.map((date) => {
            // FIX: Refined logic for handling dayCellData to ensure correct type inference
            const dayCellData = priceDataMap[date]; // Type: { [symbol: string]: HistoricalPriceEntry; } | { error?: string; }
            
            let contentToRender;

            if (dayCellData && 'error' in dayCellData && typeof dayCellData.error === 'string') {
              contentToRender = (
                <td colSpan={headers.length - 1} className="px-4 py-2.5 text-center text-gray-400 italic">
                  {dayCellData.error}
                </td>
              );
            } else if (dayCellData && dayCellData[upperSymbol] && !('error' in dayCellData && dayCellData.error) ) {
              // Ensure dayCellData is not the error variant and symbol data exists
              // The check `!('error' in dayCellData && dayCellData.error)` ensures dayCellData is not {error: "some error"}
              // Then dayCellData[upperSymbol] implies dayCellData is of type { [symbol: string]: HistoricalPriceEntry }
              const entry = dayCellData[upperSymbol] as HistoricalPriceEntry; 
              contentToRender = (
                <>
                  <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">{entry.Open?.toLocaleString()}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">{entry.High?.toLocaleString()}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">{entry.Low?.toLocaleString()}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">{entry.Close?.toLocaleString()}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">{entry.Volume?.toLocaleString()}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">{entry.Dividends?.toLocaleString()}</td>
                  <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">{entry["Stock Splits"]?.toLocaleString()}</td>
                </>
              );
            } else {
              contentToRender = (
                <td colSpan={headers.length - 1} className="px-4 py-2.5 text-center text-gray-400 italic">
                  {`Data not available for ${upperSymbol}`}
                </td>
              );
            }

            return (
              <tr key={date} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 py-2.5 whitespace-nowrap font-medium text-gray-800 sticky left-0 bg-white hover:bg-gray-50 z-0">{date}</td>
                {contentToRender}
              </tr>
            );
          })}
        </tbody>
      </>
    );

  } else { // Handles COMPANY_PROFILE, INCOME_STATEMENT, etc.
    const stockData = data as YFinanceApiResponse; // Cast to general financials type
    const tickerKey = symbol.toUpperCase();
    const symbolData = stockData[tickerKey];

    if (!symbolData) {
      return <p className="text-red-500">Data for symbol '{tickerKey}' not found in response.</p>;
    }
    if ('error' in symbolData && symbolData.error) {
      return <p className="text-red-500">Error: {symbolData.error}</p>;
    }

    if (dataType === YFinanceDataType.COMPANY_PROFILE) {
      const profileData = symbolData as YFinanceCompanyProfileData;
      const mainInfo = profileData.main_info;
      if (!mainInfo || Object.keys(mainInfo).length === 0) {
        return (
         <div className="p-4 text-center text-gray-500 italic border border-gray-200 rounded-md bg-gray-50 min-h-[140px] flex items-center justify-center">
            No company profile information available.
          </div>
        );
      }
      return renderTableContainer(
        <>
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-4 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Property</th>
              <th scope="col" className="px-4 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Value</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {Object.entries(mainInfo).map(([key, value]) => (
              <tr key={key} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 py-2.5 whitespace-nowrap font-medium text-gray-800">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</td>
                <td className="px-4 py-2.5 whitespace-normal break-words text-gray-600">{String(value)}</td>
              </tr>
            ))}
          </tbody>
        </>
      );
    } else { // Financial statements
      const statementData = symbolData as YFinanceFinancialStatementData;
      const dates = statementData.dates;
      const items = statementData.data;
      if (!dates || !items || dates.length === 0 || items.length === 0) {
         return (
            <div className="p-4 text-center text-gray-500 italic border border-gray-200 rounded-md bg-gray-50 min-h-[140px] flex items-center justify-center">
              No financial statement data available.
            </div>
          );
      }
      return renderTableContainer(
        <>
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-4 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider sticky left-0 bg-gray-50 z-10">Metric</th>
              {dates.map((date) => (
                <th key={date} scope="col" className="px-4 py-2.5 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">{date}</th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-100">
            {items.map((item: YFinanceFinancialStatementItem, index: number) => (
              <tr key={item.metric + index} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 py-2.5 whitespace-nowrap font-medium text-gray-800 sticky left-0 bg-white hover:bg-gray-50 z-0">{item.metric}</td>
                {dates.map((date) => (
                  <td key={date} className="px-4 py-2.5 whitespace-nowrap text-right text-gray-600">
                    {typeof item[date] === 'number' ? (item[date] as number).toLocaleString() : item[date]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </>
      );
    }
  }
};
