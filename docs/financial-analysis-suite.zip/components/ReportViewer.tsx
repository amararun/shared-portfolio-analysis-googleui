
import React from 'react';

interface ReportViewerProps {
  reportUrl: string | null;
}

export const ReportViewer: React.FC<ReportViewerProps> = ({ reportUrl }) => {
  return (
    <div className="mt-2">
      <h3 className="text-xl font-semibold text-gray-700 mb-3">View Report</h3>
      {/* Container for the iframe, applies overflow:hidden to clip the scaled iframe correctly */}
      <div className="w-full border border-gray-300 rounded-md shadow-inner xl:h-[calc(100vh-430px)] min-h-[340px] bg-gray-50 overflow-hidden"> {/* Reduced height */}
        {reportUrl ? (
          <iframe
            key={reportUrl} 
            src={reportUrl}
            title="Portfolio Analysis Report"
            style={{
              width: 'calc(100% / 0.90)', // Render content in a space ~111.11% of the container's width
              height: 'calc(100% / 0.90)', // Render content in a space ~111.11% of the container's height
              transform: 'scale(0.90)',    // Scale down the entire iframe (content and all) to 90%
              transformOrigin: 'top left', // Scale from the top-left corner
              border: 'none', // Ensure iframe itself has no border; parent div handles border
            }}
            allowFullScreen
            sandbox="allow-scripts allow-same-origin allow-forms" 
          >
            Loading report...
          </iframe>
        ) : (
          // Centering placeholder text within the container
          <div className="w-full h-full flex items-center justify-center p-2">
            <p className="text-gray-500 italic text-center">
              QuantStats report will appear here once generated.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
