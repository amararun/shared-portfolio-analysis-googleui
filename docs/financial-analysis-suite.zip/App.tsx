
import React, { useState } from 'react';
import { QuantStatsAnalyzer } from './components/QuantStatsAnalyzer';
import { TechnicalAnalysisAnalyzer } from './components/TechnicalAnalysisAnalyzer';
import { StockDataAnalyzer } from './components/StockDataAnalyzer';
import { PriceDataAnalyzer } from './components/PriceDataAnalyzer'; // New Import
import { 
  AnalysisParams, 
  TechnicalAnalysisFormParams, 
  TechnicalAnalysisResponse as TAResponse,
  StockDataFormParams,
  YFinanceDataType,
  YFinanceApiResponse,
  PriceDataFormParams, // New Import
  YFinanceHistoricalPricesData // New Import
} from './types';
import { getYesterdayDateString, getMonthsAgoDateString, getYearsAgoDateString } from './utils/dateUtils';

type Tab = 'quantstats' | 'technical-analysis' | 'stock-data' | 'price-data'; // Added 'price-data'

const GitHubIcon: React.FC = () => (
  <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path fillRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 4.418 2.865 8.166 6.839 9.489.5.092.682-.217.682-.483 0-.237-.009-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.026 2.747-1.026.546 1.379.202 2.398.1 2.65.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.942.359.308.678.92.678 1.852 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.001 10.001 0 0022 12c0-5.523-4.477-10-10-10z" clipRule="evenodd" />
  </svg>
);


const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('quantstats');

  const initialYesterday = getYesterdayDateString();

  // State for QuantStatsAnalyzer
  const [qsFormParams, setQsFormParams] = useState<AnalysisParams>({
    symbols: '^NSEI', 
    benchmark: '^GSPC',
    start_date: getYearsAgoDateString(10, initialYesterday), 
    end_date: initialYesterday, 
    risk_free_rate: '5',
  });
  const [qsReportUrl, setQsReportUrl] = useState<string | null>(null);
  const [qsIsLoading, setQsIsLoading] = useState<boolean>(false);
  const [qsError, setQsError] = useState<string | null>(null);

  // State for TechnicalAnalysisAnalyzer
  const [taFormParams, setTaFormParams] = useState<TechnicalAnalysisFormParams>({
    ticker: '^GSPC',
    daily_start_date: getMonthsAgoDateString(6, initialYesterday),
    daily_end_date: initialYesterday,
    weekly_start_date: getYearsAgoDateString(3, initialYesterday),
    weekly_end_date: initialYesterday,
  });
  const [taReportData, setTaReportData] = useState<TAResponse | null>(null);
  const [taIsLoading, setTaIsLoading] = useState<boolean>(false);
  const [taError, setTaError] = useState<string | null>(null);

  // State for StockDataAnalyzer (YFinance Financials)
  const [sdFormParams, setSdFormParams] = useState<StockDataFormParams>({
    symbol: 'AAPL',
    dataType: YFinanceDataType.COMPANY_PROFILE,
  });
  const [sdFetchedData, setSdFetchedData] = useState<YFinanceApiResponse | null>(null);
  const [sdIsLoading, setSdIsLoading] = useState<boolean>(false);
  const [sdError, setSdError] = useState<string | null>(null);

  // State for PriceDataAnalyzer (YFinance Historical Prices) - New
  const [priceDataFormParams, setPriceDataFormParams] = useState<PriceDataFormParams>({
    symbol: 'GOOG',
    start_date: getYearsAgoDateString(1, initialYesterday),
    end_date: initialYesterday,
  });
  const [pdFetchedData, setPdFetchedData] = useState<YFinanceHistoricalPricesData | null>(null);
  const [pdIsLoading, setPdIsLoading] = useState<boolean>(false);
  const [pdError, setPdError] = useState<string | null>(null);


  const renderTabContent = () => {
    switch (activeTab) {
      case 'quantstats':
        return (
          <QuantStatsAnalyzer
            formParams={qsFormParams}
            setFormParams={setQsFormParams}
            reportUrl={qsReportUrl}
            setReportUrl={setQsReportUrl}
            isLoading={qsIsLoading}
            setIsLoading={setQsIsLoading}
            error={qsError}
            setError={setQsError}
          />
        );
      case 'technical-analysis':
        return (
          <TechnicalAnalysisAnalyzer
            formParams={taFormParams}
            setFormParams={setTaFormParams}
            reportData={taReportData}
            setReportData={setTaReportData}
            isLoading={taIsLoading}
            setIsLoading={setTaIsLoading}
            error={taError}
            setError={setTaError}
          />
        );
      case 'stock-data':
        return (
          <StockDataAnalyzer
            formParams={sdFormParams}
            setFormParams={setSdFormParams}
            fetchedData={sdFetchedData}
            setFetchedData={setSdFetchedData}
            isLoading={sdIsLoading}
            setIsLoading={setSdIsLoading}
            error={sdError}
            setError={setSdError}
          />
        );
      case 'price-data': // New Case
        return (
          <PriceDataAnalyzer
            formParams={priceDataFormParams}
            setFormParams={setPriceDataFormParams}
            fetchedData={pdFetchedData}
            setFetchedData={setPdFetchedData}
            isLoading={pdIsLoading}
            setIsLoading={setPdIsLoading}
            error={pdError}
            setError={setPdError}
          />
        );
      default:
        return null;
    }
  };

  const TabButton: React.FC<{ tabId: Tab; currentTab: Tab; onClick: (tabId: Tab) => void; children: React.ReactNode }> = 
    ({ tabId, currentTab, onClick, children }) => (
    <button
      onClick={() => onClick(tabId)}
      className={`py-3 px-6 font-medium text-center rounded-t-lg transition-colors duration-150
                  ${currentTab === tabId 
                    ? 'bg-light-blue-600 text-white shadow-md' 
                    : 'bg-light-blue-100 text-light-blue-700 hover:bg-light-blue-200'}`}
      aria-selected={currentTab === tabId}
      role="tab"
    >
      {children}
    </button>
  );

  return (
    <div className="min-h-screen bg-light-blue-50 flex flex-col">
      <header className="bg-indigo-800 text-white shadow-md"> {/* Changed background */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14"> {/* Reduced height */}
            <div className="flex items-center">
              <img src="./fx_logo.png" alt="FX Logo" className="h-8 w-8 mr-3" /> {/* Added Logo */}
              <h1 className="text-xl font-semibold"> {/* Reduced font size */}
                Portfolio Analysis Suite
              </h1>
            </div>
            <a
              href="#" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-500 hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-light-blue-700 focus:ring-green-400 transition-colors"
            >
              <GitHubIcon />
              GitHub Repo
            </a>
          </div>
        </div>
      </header>

      <div className="flex-grow flex flex-col items-center w-full py-6 sm:py-8 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-6xl">
          <div className="mb-1 flex border-b-2 border-light-blue-200" role="tablist" aria-label="Financial Analysis Tools">
            <TabButton tabId="quantstats" currentTab={activeTab} onClick={setActiveTab}>
              QuantStats Analyzer
            </TabButton>
            <TabButton tabId="technical-analysis" currentTab={activeTab} onClick={setActiveTab}>
              Technical Analysis
            </TabButton>
            <TabButton tabId="stock-data" currentTab={activeTab} onClick={setActiveTab}> 
              Financials {/* Renamed Tab */}
            </TabButton>
            <TabButton tabId="price-data" currentTab={activeTab} onClick={setActiveTab}> {/* New Tab Button */}
              Price Data
            </TabButton>
          </div>

          <main className="mt-1 w-full bg-white p-6 sm:p-8 rounded-b-xl rounded-tr-xl shadow-xl" role="tabpanel">
            {renderTabContent()}
          </main>
        </div>
      </div>
      
      <footer className="bg-white border-t border-light-blue-200 py-4 text-sm text-light-blue-800/90">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col md:flex-row justify-between items-center gap-3">
                    <div className="text-center md:text-left text-base"> {/* Increased font size */}
                        Amar Harolikar <span className="mx-1.5 text-light-blue-400">•</span> 
                        Specialist - Decision Sciences & Applied Generative AI
                    </div>
                    <div className="flex items-center gap-x-5 gap-y-2 flex-wrap justify-center">
                        <a href="https://www.linkedin.com/in/amarharolikar" target="_blank" rel="noopener noreferrer"
                            className="text-light-blue-600 hover:text-light-blue-700 hover:underline">
                            LinkedIn
                        </a>
                        <a href="https://rex.tigzig.com" target="_blank" rel="noopener noreferrer"
                            className="text-light-blue-600 hover:text-light-blue-700 hover:underline">
                            rex.tigzig.com
                        </a>
                        <a href="https://tigzig.com" target="_blank" rel="noopener noreferrer"
                            className="text-light-blue-600 hover:text-light-blue-700 hover:underline">
                            tigzig.com
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
  );
};

export default App;
